import { useState, useEffect } from 'react';
import { toast,ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { ethers } from 'ethers';
import './App.css';
import { MetaMaskInpageProvider } from "@metamask/providers";
import axios from 'axios';
import Ipfs from './components/ipfs';

declare global {
  interface Window{
    ethereum?:MetaMaskInpageProvider
  }
}


function App() {
  const [account, setAccount] = useState<string | null>(null);
  const [contract, setContract] = useState<string>('');
  const [tokenURI, setTokenURI] = useState<string | null>(null);
  const [mintData, setMintData] = useState<string>('');
  const [tokenId, setTokenId] = useState<string>('');
  const [signer, setSigner] = useState<ethers.Signer | null>(null);
  const [requestDate, setRequestDate] = useState<string>('');
  const [requesterName, setRequesterName] = useState<string>('');
  const [requesterCompany, setRequesterCompany] = useState<string>('');
  const [programName, setProgramName] = useState<string>('');
  const [programDescription, setProgramDescription] = useState<string>('');
  const [programHash, setProgramHash] = useState<string>('');
  const [depositReceipt, setDepositReceipt] = useState<string>('');
  const [inpiTokens, setInpiTokens] = useState<Array<{ tokenId: string, metadata: any }>>([]);

  // URL to ABAKHUS API
  const api_url = "https://arbitrum.abakhus.io/api";  
  // const api_url = "http://localhost:4002/api";  

  // Your ABAKHUS API-KEY
  const api_key = ''

  // Your contract deployed at Arbitrum Sepolia
  const contractAddress = '';
  
  useEffect(() => {
    // Connect with Metamask
    const connectWallet = async () => {
      if (window.ethereum) {
        try {
          const accounts = await window.ethereum.request({ method: 'eth_requestAccounts' }) as string[];
          if (accounts && accounts.length > 0) {
            setAccount(accounts[0]);
            const provider = new ethers.BrowserProvider(window.ethereum as any);
            const signer = await provider.getSigner();
            setSigner(signer);
            setContract(contractAddress);
            
          } else {
            console.error('No accounts found');
          }
        } catch (err) {
          console.error(err);
        }
      } else {
        console.error('MetaMask is not installed');
      }
    };

    connectWallet();

    // Add event listener for account changes
    const handleAccountsChanged = (accounts: string[]) => {
      if (accounts.length > 0 && accounts[0] !== account) {
        setAccount(accounts[0]);
        window.location.reload();
      }
    };

    if (window.ethereum) {
      window.ethereum.on('accountsChanged', handleAccountsChanged as any);
    }

    // Cleanup function to remove the event listener
    return () => {
      if (window.ethereum) {
        window.ethereum.removeListener('accountsChanged', handleAccountsChanged);
      }
    };
  }, [account]); // Add account to the dependency array
  
  /**
   * Get Tokens By Owner
   */
  const getTokensByOwner = async () => {
    try {
      const signature = await signer!.signMessage("Please sign this message to verify your ownership");
      
      const response = await axios.get(`${api_url}/getTokensByOwner`, {
        params: { owner: account, signature },
        headers: {
          'x-api-key': api_key
        }
      });
      
      const tokens = response.data.ret;
      const inpiTokens = [];

      for (let i = 0; i < tokens.length; i++) {
        const tokenId = tokens[i];
        try {
          const metadataResponse = await axios.get(`${api_url}/getMetadataByTokenId`, {
            params: {owner: account, tokenId},
            headers: {
              'x-api-key': api_key
            }
          });
          const metadata = metadataResponse.data;
          console.log("Metadata: ", metadata);
          
          // Verifica se o typeToken é "inpi"
          if (metadata.metadata.metadata.typeToken === "inpi") {
            inpiTokens.push({ tokenId, metadata });
          }
        } catch (err) {
          console.error(`Error fetching metadata for Token ${tokenId}: `, err);
        }
      }

      console.log(`Retrieved ${inpiTokens.length} INPI tokens`);
      setTokenURI(`Retrieved ${inpiTokens.length} INPI tokens`);
      return inpiTokens;
    } catch (err) {
      console.error(err);
      setTokenURI("Error retrieving INPI tokens");
      return [];
    }
  };

  /**
   * mint tokens
   * @returns 
   */
  const mintToken = async () => {
    if (!account) {
      console.error('Account is not connected');
      return;
    }

    try {
      toast.info('Minting token...', {
        position: "top-right",
        autoClose: 6000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        progress: undefined,
      });

      const response = await axios.post(`${api_url}/mint`, {
        owner: account,
        data: mintData
      }, {
        headers: {
          'x-api-key': api_key
        }
      });
      
      toast.success('Token minted successfully!', {
        position: "top-right",
        autoClose: 2000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        progress: undefined,
      });
      console.log("Mint response: ", response.data);
      
    } catch (err) {
      toast.error('Token minted error!', {
        position: "top-right",
        autoClose: 5000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        progress: undefined,
      })
      console.error(err);
    }
  };

  /**
   * burn token
   */
  const burnToken = async (tokenId: string) => {
    try {
      // Lógica para queimar o token
      toast.info('Burning token...', {
        position: "top-right",
        autoClose: 5000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        progress: undefined,
      });
      console.log("Burn token");
      const response = await axios.post(`${api_url}/burn`, {
        owner: account,
        id: tokenId
      }, {
        headers: {
          'x-api-key': api_key
        }
      });
      toast.success('Token burned successfully!', {
        position: "top-right",
        autoClose: 5000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        progress: undefined,
      })
      console.log("Burn response: ", response.data);
      // Adicione a lógica de burn aqui
    } catch (err) {
      toast.error('Token burned error!', {
        position: "top-right",
        autoClose: 5000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        progress: undefined,
      })
      console.error(err);
    }
  };

  /**
   * verify ABAKHUS API
   */
  const verifyToken = async () => {
    try {
      toast.info('Verifying token...', {
        position: "top-right",
        autoClose: 5000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        progress: undefined,
      });

      // Add API key to axios headers
      const response = await axios.get(`${api_url}/verify`, {
        headers: {
          'x-api-key': api_key
        }
      });
 

      console.log("Verify response: ", response.data);
      
      toast.success('Token verified successfully!', {
        position: "top-right",
        autoClose: 5000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        progress: undefined,
      });
    } catch (err) {
      console.error(err);
      toast.error('Error verifying token!', {
        position: "top-right",
        autoClose: 5000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        progress: undefined,
      });
    }
  };

  const handleSubmitRegistration = async () => {
    if (!depositReceipt) {
      alert("Por favor, anexe o recibo do depósito antes de submeter o registro.");
      return;
    }

    const registrationData = { "metadata": {
      typeToken: "inpi", // Campo fixo adicionado
      requestDate,
      requesterName,
      requesterCompany,
      programName,
      programDescription,
      programHash,
      depositReceipt
    }};
    console.log("Registration Data: ", registrationData);
    setMintData(JSON.stringify(registrationData));
    await mintToken();
  };

  const handleGetTokens = async () => {
    const tokens = await getTokensByOwner();
    setInpiTokens(tokens);
  };

  const handleCancelRegistration = (tokenId: string) => {
    // Implement cancel logic here
    console.log(`Canceling registration for token ${tokenId}`);
    alert("Registro cancelado com sucesso! Um email será enviado para o solicitante informando o cancelamento e o token será queimado.");
    burnToken(tokenId);
    // setInpiTokens([]);
  };

  const handleApproveRegistration = (tokenId: string) => {
    // Implement approve logic here
    console.log(`Approving registration for token ${tokenId}`);
    alert("Registro aprovado com sucesso! O token será transferido para o solicitante.");
  };

  return (
    <div className="App">
      <header className="App-header">
        <h1>Interajindo com ERC 1155</h1>
        {account ? (
          <div>
          <p>Conectado: {account}</p>
          <p>Contrato: {contract}</p>
          </div>
        ) : (
          <p>Conecte sua MetaMask</p>
        )}
        
        <div className="area-do-solicitante">
          <h2>Área do Solicitante</h2>
          <div style={{display: 'flex', flexDirection: 'column', gap: '10px'}}>
            <input
              type="date"
              value={requestDate}
              onChange={(e) => setRequestDate(e.target.value)}
              placeholder="Data do pedido"
            />
            <input
              type="text"
              value={requesterName}
              onChange={(e) => setRequesterName(e.target.value)}
              placeholder="Nome do solicitante"
            />
            <input
              type="text"
              value={requesterCompany}
              onChange={(e) => setRequesterCompany(e.target.value)}
              placeholder="Empresa do solicitante"
            />
            <input
              type="text"
              value={programName}
              onChange={(e) => setProgramName(e.target.value)}
              placeholder="Nome do programa"
            />
            <textarea
              value={programDescription}
              onChange={(e) => setProgramDescription(e.target.value)}
              placeholder="Descrição do programa"
              rows={4}
            />
            <input
              type="text"
              value={programHash}
              onChange={(e) => setProgramHash(e.target.value)}
              placeholder="Código hash do programa"
            />
            <Ipfs onUpload={setDepositReceipt} />
            <button onClick={handleSubmitRegistration}>
              Submeter Registro de Software
            </button>
          </div>
        </div>
        <div className="area-do-avaliador">
          <h2>Área do Avaliador</h2>
          <button onClick={handleGetTokens}>Resgatar Tokens</button>
          
          {inpiTokens.length > 0 ? (
            <table>
              <thead>
                <tr>
                  <th>Data do Pedido</th>
                  <th>Nome do Programa</th>
                  <th>Arquivo IPFS</th>
                  <th>Ações</th>
                </tr>
              </thead>
              <tbody>
                {inpiTokens.map(({ tokenId, metadata }) => (
                  <tr key={tokenId}>
                    <td>{metadata.metadata.metadata.requestDate}</td>
                    <td>{metadata.metadata.metadata.programName}</td>
                    <td>
                      <a href={`${metadata.metadata.metadata.depositReceipt}`} target="_blank" rel="noopener noreferrer">
                        Ver Arquivo
                      </a>
                    </td>
                    <td>
                      <button onClick={() => handleCancelRegistration(tokenId)}>Cancelar Registro</button>
                      <button onClick={() => handleApproveRegistration(tokenId)}>Aprovar Registro</button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          ) : (
            <p>Não há registros para análise</p>
          )}
        </div>
        <ToastContainer />
      </header>
    </div>
  );
}

export default App;
